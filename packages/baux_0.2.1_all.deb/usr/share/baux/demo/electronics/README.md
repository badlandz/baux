Demo: Wi-Fi Sniffer with BAUX
1. Edit in Neovim
2. Compile with arduino-cli
3. Flash via USB

# Repo References

- **legacy-baux**: Archived gutted parts (coyoteUI keymaps, bashrc aliases, Wi-Fi-Sniffer demos).
- **badlandz-nvim-init.lua** (fork idea): Legal doc editing – merge into nvim/legal-fork/.

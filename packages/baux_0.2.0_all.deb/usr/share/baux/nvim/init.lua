vim.g.mapleader = " "
require("lazy").setup({
  "ellisonleao/gruvbox.nvim",
  "ibhagwan/fzf-lua",
})
vim.cmd("colorscheme gruvbox")

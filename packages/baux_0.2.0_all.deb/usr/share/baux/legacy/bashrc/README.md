# Bash Stuff

This is a test.

It has some prerequisites, and needs documentation.

apt -y remove baux; apt -y install ~/baux_0.2.0_all.deb
